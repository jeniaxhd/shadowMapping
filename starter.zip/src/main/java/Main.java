package main.java;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL;

import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.system.MemoryUtil.NULL;

/**
 * Shadow Mapping Workshop — audience starter
 *
 * Baseline:
 * - floor + cubes
 * - Phong lighting
 * - NO shadows yet
 *
 * During the workshop you will implement:
 * 1) depth pass
 * 2) light-space transform
 * 3) shadow test in the main pass
 * 4) optional PCF filtering
 */
public class Main {

    static final int WIDTH  = 1280;
    static final int HEIGHT = 720;

    static float camYaw   = -90f;
    static float camPitch = -20f;
    static float camDist  = 10f;
    static float lastX = WIDTH / 2f, lastY = HEIGHT / 2f;
    static boolean firstMouse = true;

    static final Vector3f LIGHT_POS = new Vector3f(3.0f, 5.0f, 3.0f);

    static final int SHADOW_WIDTH  = 1024;
    static final int SHADOW_HEIGHT = 1024;

    static int mainShader;
    static int depthShader;

    static int floorVAO, cubeVAO;

    static int shadowFBO;
    static int shadowMapTexture;

    static Matrix4f projection;
    static Matrix4f view;
    static Matrix4f lightSpaceMatrix;

    public static void main(String[] args) {
        if (!glfwInit()) throw new RuntimeException("GLFW init failed");

        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

        long window = glfwCreateWindow(WIDTH, HEIGHT, "Shadow Mapping Workshop", NULL, NULL);
        if (window == NULL) throw new RuntimeException("Window creation failed");

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        GL.createCapabilities();

        glfwSetCursorPosCallback(window, (win, xpos, ypos) -> {
            if (glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_LEFT) != GLFW_PRESS) {
                firstMouse = true;
                return;
            }
            if (firstMouse) {
                lastX = (float) xpos;
                lastY = (float) ypos;
                firstMouse = false;
            }
            float dx = (float) xpos - lastX;
            float dy = lastY - (float) ypos;
            lastX = (float) xpos;
            lastY = (float) ypos;
            camYaw += dx * 0.3f;
            camPitch = Math.max(-89f, Math.min(89f, camPitch + dy * 0.3f));
        });

        glfwSetScrollCallback(window, (win, xoff, yoff) -> {
            camDist = Math.max(2f, Math.min(30f, camDist - (float) yoff));
        });

        glfwSetKeyCallback(window, (win, key, scancode, action, mods) -> {
            if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
                glfwSetWindowShouldClose(win, true);
        });

        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

        System.out.println("OpenGL: " + glGetString(GL_VERSION));
        System.out.println("Working directory: " + System.getProperty("user.dir"));

        glEnable(GL_DEPTH_TEST);

        mainShader = loadShader("shaders/main.vert", "shaders/main.frag");

        /*
         * Workshop task:
         * Load the depth shader program once depth.vert and depth.frag are ready.
         * It will be used only in the depth pass from the light's point of view.
         */
        depthShader = 0;

        floorVAO = createCube();
        cubeVAO  = createCube();

        projection = new Matrix4f().perspective(
                (float) Math.toRadians(45.0f), (float) WIDTH / HEIGHT, 0.1f, 100.0f);
        view = new Matrix4f().lookAt(
                new Vector3f(0f, 6f, 10f),
                new Vector3f(0f, 0f, 0f),
                new Vector3f(0f, 1f, 0f));

        initShadowResources();
        lightSpaceMatrix = buildLightSpaceMatrix();

        while (!glfwWindowShouldClose(window)) {
            glfwPollEvents();

            renderDepthPass();

            glViewport(0, 0, WIDTH, HEIGHT);
            glClearColor(0.08f, 0.10f, 0.14f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            float yawRad   = (float) Math.toRadians(camYaw);
            float pitchRad = (float) Math.toRadians(camPitch);
            Vector3f camPos = new Vector3f(
                    camDist * (float) (Math.cos(pitchRad) * Math.cos(yawRad)),
                    camDist * (float) Math.sin(pitchRad),
                    camDist * (float) (Math.cos(pitchRad) * Math.sin(yawRad))
            );
            view = new Matrix4f().lookAt(camPos, new Vector3f(0f), new Vector3f(0f, 1f, 0f));

            glUseProgram(mainShader);
            setUniformMat4(mainShader, "projection", projection);
            setUniformMat4(mainShader, "view", view);
            setUniformVec3(mainShader, "lightPos", LIGHT_POS);
            setUniformVec3(mainShader, "viewPos", camPos);
            setUniformVec3(mainShader, "lightColor", new Vector3f(1f, 1f, 1f));

            bindShadowDataForMainPass();
            renderScene(mainShader);

            glfwSwapBuffers(window);
        }

        glfwTerminate();
    }

    static void initShadowResources() {
        /*
         * WORKSHOP TASK A — shadow framebuffer and depth texture
         *
         * Create all GPU resources needed for pass 1:
         * - framebuffer object for off-screen rendering
         * - 2D depth texture with size SHADOW_WIDTH × SHADOW_HEIGHT
         * - attach the texture as GL_DEPTH_ATTACHMENT
         * - disable color outputs for this framebuffer
         * - use clamp-to-border so fragments outside the map are treated as lit
         *
         * Expected result after this task alone:
         * The application still looks the same, but the shadow pipeline has storage for the depth pass.
         */
    }

    static Matrix4f buildLightSpaceMatrix() {
        /*
         * WORKSHOP TASK B — light-space matrix
         *
         * Build the matrix that transforms world coordinates into the light's clip space.
         * For this workshop use:
         * - orthographic projection (directional-light mental model)
         * - lookAt from LIGHT_POS toward the scene center
         *
         * Return: lightProjection * lightView
         *
         * Tip:
         * The visible scene must fit inside the light frustum, otherwise shadows will disappear or clip.
         */
        return new Matrix4f();
    }

    static void renderDepthPass() {
        /*
         * WORKSHOP TASK C — first rendering pass
         *
         * Render the scene from the light's point of view into the depth texture.
         * Steps:
         * 1. Switch viewport to SHADOW_WIDTH × SHADOW_HEIGHT.
         * 2. Bind shadowFBO.
         * 3. Clear only the depth buffer.
         * 4. Use depthShader.
         * 5. Upload lightSpaceMatrix.
         * 6. Render the same scene geometry.
         * 7. Return to the default framebuffer.
         *
         * Expected demo moment:
         * After this task, you can optionally visualize the depth map for debugging.
         */
    }

    static void bindShadowDataForMainPass() {
        /*
         * WORKSHOP TASK D — connect pass 1 to pass 2
         *
         * Before drawing the visible scene:
         * - upload lightSpaceMatrix to the main shader
         * - bind the depth texture to texture unit 0
         * - set sampler uniform shadowMap = 0
         *
         * Note:
         * This method is intentionally separate so the data flow is obvious: pass 1 produces the map, pass 2 consumes it.
         */
    }

    static void renderScene(int shader) {
        Matrix4f model = new Matrix4f().translate(0f, -0.5f, 0f).scale(10f, 0.2f, 10f);
        setUniformMat4(shader, "model", model);
        setUniformVec3(shader, "objectColor", new Vector3f(0.4f, 0.5f, 0.6f));
        glBindVertexArray(floorVAO);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        model = new Matrix4f().translate(0f, 0.5f, 0f);
        setUniformMat4(shader, "model", model);
        setUniformVec3(shader, "objectColor", new Vector3f(0.7f, 0.3f, 0.2f));
        glBindVertexArray(cubeVAO);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        model = new Matrix4f().translate(2f, 0.25f, -1f).scale(0.5f, 0.5f, 0.5f);
        setUniformMat4(shader, "model", model);
        setUniformVec3(shader, "objectColor", new Vector3f(0.2f, 0.6f, 0.3f));
        glBindVertexArray(cubeVAO);
        glDrawArrays(GL_TRIANGLES, 0, 36);
    }

    static int createCube() {
        float[] v = {
                -0.5f,-0.5f,-0.5f, 0f, 0f,-1f,  0.5f,-0.5f,-0.5f, 0f, 0f,-1f,  0.5f, 0.5f,-0.5f, 0f, 0f,-1f,
                 0.5f, 0.5f,-0.5f, 0f, 0f,-1f, -0.5f, 0.5f,-0.5f, 0f, 0f,-1f, -0.5f,-0.5f,-0.5f, 0f, 0f,-1f,
                -0.5f,-0.5f, 0.5f, 0f, 0f, 1f,  0.5f,-0.5f, 0.5f, 0f, 0f, 1f,  0.5f, 0.5f, 0.5f, 0f, 0f, 1f,
                 0.5f, 0.5f, 0.5f, 0f, 0f, 1f, -0.5f, 0.5f, 0.5f, 0f, 0f, 1f, -0.5f,-0.5f, 0.5f, 0f, 0f, 1f,
                -0.5f, 0.5f, 0.5f,-1f, 0f, 0f, -0.5f, 0.5f,-0.5f,-1f, 0f, 0f, -0.5f,-0.5f,-0.5f,-1f, 0f, 0f,
                -0.5f,-0.5f,-0.5f,-1f, 0f, 0f, -0.5f,-0.5f, 0.5f,-1f, 0f, 0f, -0.5f, 0.5f, 0.5f,-1f, 0f, 0f,
                 0.5f, 0.5f, 0.5f, 1f, 0f, 0f,  0.5f, 0.5f,-0.5f, 1f, 0f, 0f,  0.5f,-0.5f,-0.5f, 1f, 0f, 0f,
                 0.5f,-0.5f,-0.5f, 1f, 0f, 0f,  0.5f,-0.5f, 0.5f, 1f, 0f, 0f,  0.5f, 0.5f, 0.5f, 1f, 0f, 0f,
                -0.5f,-0.5f,-0.5f, 0f,-1f, 0f,  0.5f,-0.5f,-0.5f, 0f,-1f, 0f,  0.5f,-0.5f, 0.5f, 0f,-1f, 0f,
                 0.5f,-0.5f, 0.5f, 0f,-1f, 0f, -0.5f,-0.5f, 0.5f, 0f,-1f, 0f, -0.5f,-0.5f,-0.5f, 0f,-1f, 0f,
                -0.5f, 0.5f,-0.5f, 0f, 1f, 0f,  0.5f, 0.5f,-0.5f, 0f, 1f, 0f,  0.5f, 0.5f, 0.5f, 0f, 1f, 0f,
                 0.5f, 0.5f, 0.5f, 0f, 1f, 0f, -0.5f, 0.5f, 0.5f, 0f, 1f, 0f, -0.5f, 0.5f,-0.5f, 0f, 1f, 0f,
        };
        int vao = glGenVertexArrays();
        int vbo = glGenBuffers();
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        FloatBuffer buf = BufferUtils.createFloatBuffer(v.length);
        buf.put(v).flip();
        glBufferData(GL_ARRAY_BUFFER, buf, GL_STATIC_DRAW);
        glVertexAttribPointer(0, 3, GL_FLOAT, false, 6 * 4, 0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 3, GL_FLOAT, false, 6 * 4, 3 * 4);
        glEnableVertexAttribArray(1);
        glBindVertexArray(0);
        return vao;
    }

    static int loadShader(String vertPath, String fragPath) {
        String vertSrc = readFile(vertPath);
        String fragSrc = readFile(fragPath);

        int vert = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vert, vertSrc);
        glCompileShader(vert);
        if (glGetShaderi(vert, GL_COMPILE_STATUS) == GL_FALSE)
            throw new RuntimeException("Vertex shader error [" + vertPath + "]:\n" + glGetShaderInfoLog(vert));

        int frag = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(frag, fragSrc);
        glCompileShader(frag);
        if (glGetShaderi(frag, GL_COMPILE_STATUS) == GL_FALSE)
            throw new RuntimeException("Fragment shader error [" + fragPath + "]:\n" + glGetShaderInfoLog(frag));

        int prog = glCreateProgram();
        glAttachShader(prog, vert);
        glAttachShader(prog, frag);
        glLinkProgram(prog);
        if (glGetProgrami(prog, GL_LINK_STATUS) == GL_FALSE)
            throw new RuntimeException("Shader link error:\n" + glGetProgramInfoLog(prog));

        glDeleteShader(vert);
        glDeleteShader(frag);
        return prog;
    }

    static String readFile(String path) {
        try {
            return new String(Files.readAllBytes(Paths.get(path)));
        } catch (IOException e) {
            throw new RuntimeException(
                    "Shader file not found: " + path +
                    "\nMake sure the 'shaders/' folder is in the project root: " +
                    System.getProperty("user.dir"), e);
        }
    }

    static void setUniformMat4(int prog, String name, Matrix4f mat) {
        FloatBuffer buf = BufferUtils.createFloatBuffer(16);
        mat.get(buf);
        glUniformMatrix4fv(glGetUniformLocation(prog, name), false, buf);
    }

    static void setUniformVec3(int prog, String name, Vector3f v) {
        int location = glGetUniformLocation(prog, name);
        if (location != -1) glUniform3f(location, v.x, v.y, v.z);
    }

    static void setUniformInt(int prog, String name, int val) {
        int location = glGetUniformLocation(prog, name);
        if (location != -1) glUniform1i(location, val);
    }
}
