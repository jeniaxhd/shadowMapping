#version 330 core

layout(location = 0) in vec3 aPos;

uniform mat4 lightSpaceMatrix;
uniform mat4 model;

/*
 * WORKSHOP TASK (depth.vert)
 *
 * This shader is used in pass 1.
 * It must place every vertex into the clip space of the light.
 *
 * Write the position transform for:
 * light projection * light view * model * local position
 */

void main() {
    gl_Position = vec4(aPos, 1.0);
}
