#version 330 core

in vec3 FragPos;
in vec3 Normal;

/*
 * WORKSHOP TASK (main.frag)
 *
 * Add the data path for the shadow test:
 * - receive FragPosLightSpace from the vertex shader
 * - add uniform sampler2D shadowMap
 * - write a function that compares current depth with the stored depth
 * - blend the result into the diffuse/specular lighting
 *
 * Important:
 * You will also need a small bias to reduce self-shadowing artifacts.
 */

uniform vec3 lightPos;
uniform vec3 viewPos;
uniform vec3 lightColor;
uniform vec3 objectColor;

out vec4 FragColor;

void main() {
    vec3 norm     = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    vec3 viewDir  = normalize(viewPos - FragPos);
    vec3 reflDir  = reflect(-lightDir, norm);

    float ambient = 0.15;
    float diff    = max(dot(norm, lightDir), 0.0);
    float spec    = pow(max(dot(viewDir, reflDir), 0.0), 32.0);

    vec3 lighting = (ambient + diff + spec * 0.3) * lightColor;
    FragColor = vec4(lighting * objectColor, 1.0);
}
