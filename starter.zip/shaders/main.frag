#version 330 core

in vec3 FragPos;
in vec3 Normal;

// [CV2] Pridaj in premennú pre light space pozíciu
// in vec4 FragPosLightSpace;

uniform vec3 lightPos;
uniform vec3 viewPos;
uniform vec3 lightColor;
uniform vec3 objectColor;

// [CV2] Pridaj uniform shadowMap
// uniform sampler2D shadowMap;

out vec4 FragColor;

// ── [CV2] Shadow test funkcia ─────────────────────────────────────────────
// TODO: Implementuj túto funkciu
//
// float shadowTest(vec4 fragPosLightSpace) {
//
//     // 1. Normalizuj do rozsahu [0, 1]
//     vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
//     projCoords = projCoords * 0.5 + 0.5;
//
//     // 2. Vzorkuj depth mapu
//     float closestDepth = texture(shadowMap, projCoords.xy).r;
//
//     // 3. Hĺbka aktuálneho fragmentu
//     float currentDepth = projCoords.z;
//
//     // 4. Bias — zabraňuje shadow acne
//     float bias = 0.005;
//
//     // 5. Shadow test
//     float shadow = (currentDepth - bias > closestDepth) ? 1.0 : 0.0;
//
//     // Fragmenty mimo depth mapy nie sú v tieni
//     if (projCoords.z > 1.0) shadow = 0.0;
//
//     return shadow;
// }

void main() {
    // Phong osvetlenie
    vec3 norm    = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    vec3 viewDir  = normalize(viewPos  - FragPos);
    vec3 reflDir  = reflect(-lightDir, norm);

    float ambient  = 0.15;
    float diff     = max(dot(norm, lightDir), 0.0);
    float spec     = pow(max(dot(viewDir, reflDir), 0.0), 32.0);

    // ── [CV2] Zakomponuj tieň ─────────────────────────────────────────────
    // TODO: float shadow = shadowTest(FragPosLightSpace);
    float shadow = 0.0; // <- toto zmaž keď budeš mať shadowTest

    vec3 lighting = (ambient + (1.0 - shadow) * (diff + spec * 0.3)) * lightColor;
    FragColor = vec4(lighting * objectColor, 1.0);
}
