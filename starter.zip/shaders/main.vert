#version 330 core

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

// [CV2] Pridaj uniform lightSpaceMatrix
// uniform mat4 lightSpaceMatrix;

out vec3 FragPos;
out vec3 Normal;

// [CV2] Pridaj out premennú pre light space pozíciu
// out vec4 FragPosLightSpace;

void main() {
    FragPos = vec3(model * vec4(aPos, 1.0));
    Normal  = mat3(transpose(inverse(model))) * aNormal;

    // [CV2] Vypočítaj FragPosLightSpace
    // FragPosLightSpace = lightSpaceMatrix * vec4(FragPos, 1.0);

    gl_Position = projection * view * vec4(FragPos, 1.0);
}
