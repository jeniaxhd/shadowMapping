#version 330 core

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

/*
 * WORKSHOP TASK (main.vert)
 *
 * Extend this shader for shadow mapping:
 * - add uniform mat4 lightSpaceMatrix
 * - add out vec4 FragPosLightSpace
 * - compute the fragment position in light space
 *
 * Goal:
 * The fragment shader must know where the visible fragment lies in the light's depth map.
 */

out vec3 FragPos;
out vec3 Normal;

void main() {
    FragPos = vec3(model * vec4(aPos, 1.0));
    Normal  = mat3(transpose(inverse(model))) * aNormal;

    gl_Position = projection * view * vec4(FragPos, 1.0);
}
