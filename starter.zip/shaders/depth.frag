#version 330 core
void main() {
    // prázdne — gl_FragDepth sa nastaví automaticky
}
