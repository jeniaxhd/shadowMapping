#version 330 core

// [CV1] Depth fragment shader — zámerne prázdny.
// OpenGL zapíše hĺbku do depth bufferu automaticky.
// Tento súbor netreba meniť.

void main() {
    // prázdne — gl_FragDepth sa nastaví automaticky
}
