#version 330 core

/*
 * WORKSHOP TASK (depth.frag)
 *
 * This shader can stay effectively empty.
 * The important part is that pass 1 renders only depth into the depth attachment.
 *
 * Key idea to explain:
 * OpenGL writes the fragment depth automatically.
 */

void main() {
}
